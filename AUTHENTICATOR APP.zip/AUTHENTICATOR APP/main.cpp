#include "Auth/Auth.h"
#include "AppManager/AppManager.h"
#include <iostream>
#include <windows.h>

// Function to hide the console window (optional)
void HideConsole()
{
    HWND hwnd = GetConsoleWindow();
    ShowWindow(hwnd, SW_HIDE);
}

int main() {
    // Uncomment to run in background without console window
    // HideConsole();

    try {
        // Authentication phase
        if (!Authenticator::authenticateUser()) {
            std::cerr << "Authentication failed. Exiting..." << std::endl;
            MessageBoxA(NULL, "Authentication failed!", "App Access Control", MB_ICONERROR);
            return 1;
        }

        // Initialize application monitor
        AppMonitor monitor;
        
        // Add protected applications
        monitor.addProtectedApp("notepad.exe");
        monitor.addProtectedApp("calc.exe");
        monitor.addProtectedApp("chrome.exe");  // Additional example
        
        // Add configuration file loading here if needed
        // monitor.loadConfig("config.txt");

        std::cout << "Starting application monitoring service..." << std::endl;
        MessageBoxA(NULL, "Access control activated", "App Access Control", MB_ICONINFORMATION);
        
        // Start the monitoring loop
        monitor.startMonitoring();
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        MessageBoxA(NULL, e.what(), "Critical Error", MB_ICONERROR);
        return -1;
    }

    return 0;
}
