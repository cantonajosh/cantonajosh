#include "Auth.h"
#include <iostream>
#include <windows.h>

std::vector<User> Authenticator::users = {
    {"admin", "$2a$10$N9qo8uLOickgx2ZMRZoMy...", true},
    {"user", "$2a$10$bW7JhK8uLOickgx2ZMRZoMy...", false}
};

bool Authenticator::authenticateUser() {
    std::string username, password;
    std::cout << "Access Control System\n";
    std::cout << "Username: ";
    std::cin >> username;
    std::cout << "Password: ";
    
    HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
    DWORD mode = 0;
    GetConsoleMode(hStdin, &mode);
    SetConsoleMode(hStdin, mode & (~ENABLE_ECHO_INPUT));
    
    std::cin >> password;
    SetConsoleMode(hStdin, mode);
    std::cout << std::endl;

    return verifyCredentials(username, password);
}

bool Authenticator::verifyCredentials(const std::string& user, const std::string& pass) {
    for (const auto& u : users) {
        if (u.username == user) {
            // In real implementation, use proper bcrypt verification
            if (pass == "demo") { // Replace with actual hash verification
                return true;
            }
        }
    }
    return false;
}
