#pragma once
#include <string>
#include <vector>

struct User {
    std::string username;
    std::string passwordHash;
    bool isAdmin;
};

class Authenticator {
    static std::vector<User> users;
public:
    static bool authenticateUser();
    static bool verifyCredentials(const std::string& user, const std::string& pass);
    static void loadUsers();
};
