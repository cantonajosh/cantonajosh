#include "AppManager.h"
#include <iostream>

void AppMonitor::addProtectedApp(const std::string& appName) {
    protectedApps.push_back(appName);
}

bool AppMonitor::isAppRunning(const std::string& processName) {
    PROCESSENTRY32 entry;
    entry.dwSize = sizeof(PROCESSENTRY32);
    
    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);
    
    if (Process32First(snapshot, &entry)) {
        while (Process32Next(snapshot, &entry)) {
            if (!_stricmp(entry.szExeFile, processName.c_str())) {
                CloseHandle(snapshot);
                return true;
            }
        }
    }
    CloseHandle(snapshot);
    return false;
}

void AppMonitor::logAccessAttempt(const std::string& appName, bool success) {
    // In a real implementation, write to a log file
    std::cout << "Access " << (success ? "granted" : "denied") 
              << " to " << appName << std::endl;
}

void AppMonitor::startMonitoring() {
    std::cout << "Starting application monitoring..." << std::endl;
    
    while (true) {
        for (const auto& app : protectedApps) {
            if (isAppRunning(app)) {
                logAccessAttempt(app, true);
                // In real implementation, you might terminate unauthorized access
                // system(("taskkill /IM " + app + " /F").c_str());
            }
        }
        Sleep(5000); // Check every 5 seconds
    }
}
