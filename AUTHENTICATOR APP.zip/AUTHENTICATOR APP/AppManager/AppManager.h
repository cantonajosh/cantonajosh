#pragma once
#include <vector>
#include <string>
#include <windows.h>
#include <tlhelp32.h>

class AppMonitor {
    std::vector<std::string> protectedApps;
    
    bool isAppRunning(const std::string& processName);
    void logAccessAttempt(const std::string& appName, bool success);
    
public:
    void startMonitoring();
    void addProtectedApp(const std::string& appName);
};
